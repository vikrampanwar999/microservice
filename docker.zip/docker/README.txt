Hi,

I have seperate the dockercompose file into 6 pieces or files for more visibility and use.

You should to run theme in order of number in there file name.

==>  So you have also to wait to the deploiement of the runing docker before to run the next

--------------------------------- CMDS : ---------------------------------
Nb. Each CMD in separate Windows CMD  !!!!


1- Kafka & Zookeeper : 
docker-compose -f 1-zookeeper-kafka.yml up

2- Discovery & Gateway :
docker-compose -f 2-discovery-gateway.yml up

3- Product MS :
docker-compose -f 3-product-service.yml up

4- Cart MS :
docker-compose -f 4-cart-service.yml up

5- Checkout MS :
docker-compose -f 5-checkout-service.yml up

6- User MS
docker-compose -f 6-user-service.yml up


--------------------------------- VERIFICATION : ---------------------------------
1- eureka :

http://127.0.0.1:8761/

liste of instances : 

ECOM-API-GATEWAY	n/a (1)	(1)	UP (1) - XXXXX:ecom-api-gateway:8080
ECOM-CART-SERVICE	n/a (1)	(1)	UP (1) - XXXXX:ecom-cart-service:8083
ECOM-CHECKOUT-SERVICE	n/a (1)	(1)	UP (1) - XXXXX:ecom-checkout-service:8084
ECOM-PRODUCT-SERVICE	n/a (1)	(1)	UP (1) - XXXXX:ecom-product-service:8082


2- services : 

BY USING GATEWAY

- product : http://127.0.0.1:8080/api/product/
- cart : http://127.0.0.1:8080/api/cart/
- checkout : http://127.0.0.1:8080/api/checkout/

BY WITHOUT USING GATEWAY

- product : http://127.0.0.1:8082/api/product/
- cart : http://127.0.0.1:8083/api/cart/
- checkout : http://127.0.0.1:8084/api/checkout/

User service

- user : http://127.0.0.1:8181/api/user/

